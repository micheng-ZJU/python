__author__ = 'micheng'

from distutils.core import setup

setup(
    name='nester',
    version='1.1.0',
    py_modules=['nester'],
    author='mingcheng',
    author_email='micheng@microstrategy.com',
    description='A simple printer of nested lists',
)